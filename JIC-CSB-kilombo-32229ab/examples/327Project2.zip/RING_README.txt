CECS 327 - Distributed Systems
Ring Kilombo Project
-------Team Members-------
Isaac Chavez
Adam Flores
Mark Tan
-------------

Documentation found in the html folder under the index.html file.
ring folder represents the team code, while orig ring folder represents the professor edited work during office hours.