var searchData=
[
  ['ring_2ec',['ring.c',['../ring_8c.html',1,'']]]
];
