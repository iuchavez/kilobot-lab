var searchData=
[
  ['recv_5felected',['recv_elected',['../ring_8c.html#a99c4cc2374067eeaf9afdf48c7a2924a',1,'ring.c']]],
  ['recv_5felection',['recv_election',['../ring_8c.html#ac178becefc5a6cb069d7204976ae4506',1,'ring.c']]],
  ['recv_5fjoining',['recv_joining',['../ring_8c.html#a27b20f1b26960043194f20584b81f3c9',1,'ring.c']]],
  ['recv_5fmove',['recv_move',['../ring_8c.html#aa29591f5cf15a4b280882e6f1f91e3be',1,'ring.c']]],
  ['recv_5fsharing',['recv_sharing',['../ring_8c.html#ad8d6e8bd005b92febac972bac5171128',1,'ring.c']]],
  ['remove_5fneighbor',['remove_neighbor',['../ring_8c.html#aa5dfa0333a1d16d7016ae65a29ff98c6',1,'ring.c']]],
  ['reset_5fself',['reset_self',['../ring_8c.html#a8f5448d1f75a1e052ad39340ac6947ae',1,'ring.c']]],
  ['ring_2ec',['ring.c',['../ring_8c.html',1,'']]]
];
