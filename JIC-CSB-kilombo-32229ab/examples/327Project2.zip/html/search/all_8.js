var searchData=
[
  ['update_5fcolor',['update_color',['../ring_8c.html#a8807611add654242fa535446222a59f0',1,'ring.c']]]
];
