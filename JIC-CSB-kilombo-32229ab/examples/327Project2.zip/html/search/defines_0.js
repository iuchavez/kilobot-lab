var searchData=
[
  ['simulator',['SIMULATOR',['../ring_8c.html#ad8a5d8c4e3342fb668142df792e93f38',1,'ring.c']]]
];
